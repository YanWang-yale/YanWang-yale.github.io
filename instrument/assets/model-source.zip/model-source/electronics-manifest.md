# Acquisition electronics asset manifest

Source: `electronics.py`. Built and tested with Blender 4.5.13 LTS on 2026-09-07. This is a proposed cage-external monitoring assembly, based on the final proposal BOM in `work-notes/funding-instrument-evidence.md`. It is a visualization, not production CAD or verified operational hardware.

## Import and hierarchy

```python
from electronics import build_electronics, get_anchor_positions
electronics = build_electronics(parent=instrument_root, ups_drop=-0.0255)
electronics.location = (0.216, 0.015, 0.026)
anchors = get_anchor_positions(electronics)
```

The function returns `Electronics_Assembly`, an Empty at local origin, metres, Z-up. It does not reset the scene, change units, add lights/cameras, save a file or render. Every material name is prefixed `EL_`; if that material already exists, its parent-side tuning is preserved. Geometry is created from local mesh helpers and one evaluated Boolean operation for the Pi mounting holes. There are no external assets or addons.

All twelve original component groups remain. Two distinct adapter groups are parented to the UPS, and `EL_Power_Cables` contains pose-aware DC routing. Each group stores `home_position`, `explode_offset`, `component_id` and status metadata. The lid, PCB and cooler can move independently. Hide the power-cable group during exploded views. Set UPS height through `build_electronics(..., ups_drop=...)`; do not subsequently translate the UPS alone, because the fixed-device ends of the power cables must remain seated. Calling the original API without the optional argument still gives the neutral `ups_drop=0` layout.

Verified current budget: **42 material meshes, 47,388 triangles**. The function asserts at most 45 meshes and 54,000 triangles. Current three-pose geometry/connection evidence is `model-source/electronics-power-validation.json`; the older work-notes report predates complete power routing.

## Dimensions and placements

Coordinates below are relative to the returned assembly. X is left/right, Y rear/front (front is negative Y), Z is up. Dimensions exclude cords unless noted.

| Component | Assembly placement / envelope | Evidence and limits |
|---|---|---|
| Carrier | Centre `(0,0)`; 230 × 160 mm; feet touch Z=0; top Z=17.6 mm | Designed carrier, not a purchased product. Acquisition hardware reaches approximately Z=60 mm; it fits within the requested 100 mm height allowance. |
| Pi 5 PCB | Centre X=−55, Y=8 mm; 85 × 56 × 1.6 mm board; midplane Z=30.3 mm | 85 × 56 mm and 58 × 49 mm mounting pattern from the official mechanical drawing. Four 2.7 mm mounting holes are genuinely cut. PCB thickness, component placement and component heights are visual approximations. The drawing itself is reference-only and directs users to the physical board for complete components. [Raspberry Pi mechanical drawing](https://datasheets.raspberrypi.com/rpi5/raspberry-pi-5-mechanical-drawing.pdf) |
| Pi fan case | Same XY centre; 100 × 72 mm; lower Z=18 mm; complete top about 59.7 mm | Designed vented case matching the BOM's fan-case role, not an exact replica of a specified case SKU. Includes real openings, seam, lid fasteners, rear FPC opening, cooler, fan, GPIO header, ICs, passives, microSD and connector sleeves. |
| Powered hub | Centre X=51, Y=−2 mm; nominal case 103 × 60 × 22 mm | Manufacturer envelope, four USB3 data ports, a separate charging port and blue status lenses. Connector protrusions give a rendered total depth near 66 mm. Port coordinates, stepped USB3 Type-B upstream shape and fine casing detail are approximated. [StarTech ST53004U1C](https://www.startech.com/en-us/usb-hubs/st53004u1c) |
| Data drives A/B | Dock origins `(16.5,−32,30.5)` and `(39.5,−32,30.5)` mm | **Two Raspberry Pi USB Flash Drives, 256 GB each**, not SSDs. Each 42 × 12.2 × 6.5 mm envelope; connector end 4.6 mm thick. About 9 mm is inserted. Aluminum body, lanyard aperture, USB tongue and A/B identifying marks are modeled; fine profile/engraving is approximate. [Raspberry Pi Flash Drive dimensions](https://www.raspberrypi.com/documentation/accessories/usb.html#flash-drive-dimensions) |
| RTC | Centre X=42, Y=57 mm; board 33 × 22 mm; base Z=18 mm | DS3231 + CR1220 role from P08/P09. PCB size/layout and miniature I2C connector are proposed visual details, not a verified supplier-board reconstruction. |
| UPS | Neutral group origin `(340,0,0)` mm, with requested `ups_drop` applied once; body 274 × 105 × 139 mm | APC BE600M1, seven NEMA outlets (five backup, two surge-only), a USB charging port and status/power button. Dimensions from a Schneider-authored BE600M1 product sheet; outlet positions, case details and short resting cord are approximate. Cord/plug expand the group to roughly 307 × 134.5 × 139.1 mm, before adding adapters. [Manufacturer product page](https://www.se.com/us/en/product/BE600M1/apc-backups-600va-120v-1-usb-charging-port-7-nema-outlets-2-surge/), [Schneider-authored dimensional sheet](https://www.farnell.com/datasheets/3959514.pdf) |
| Pi 27 W adapter | 36 × 52 × 52 mm body above backup outlet 1; Type-A blades point down into outlet | Official Type-A envelope, rotated for the upward-facing socket. Captive USB-C cable is routed through a restrained coil; measured centreline is 1.234 m at the adopted pose, within the source's 1.2 m ±80 mm reference length. [Raspberry Pi 27 W supply drawing](https://datasheets.raspberrypi.com/power-supply/27w-usb-c-power-supply-product-brief.pdf) |
| Hub adapter | 38 × 48 × 39 mm body above backup outlet 2 | Designed envelope; 12 V / 2 A output and included AC adapter role from StarTech. Its separate DC cable terminates in the hub barrel connector. |

The carrier, fan case, adapter representation, cable routing, RTC-board size, and most component-level detail are explicitly designed approximations. No LCD/display, actuator, heater, cooler controller, ultrasound device or fabricated physiological sensor has been added. The model does not establish possession, funding, procurement, calibration, electrical suitability or enclosure ventilation performance.

## Connection anchors

`electronics.ANCHORS` exposes the following neutral (`ups_drop=0`) assembly-local positions and outward normals. Entries tagged `moves_with_ups` add the requested drop to Z. Each named Empty is parented to the relevant component. Use `get_anchor_positions(electronics)` for tested live local/world positions and normals. The adopted root pose and exact power-anchor coordinates are also printed in `electronics-power-review.md`.

| Key / Empty | Position in metres | Outward normal | Routing meaning |
|---|---|---|---|
| `thermal_usb_in` / `EL_USB_Thermal_Camera_In` | `(0.0625,−0.0355,0.0305)` | `(0,−1,0)` | Free hub data port for PureThermal 3 USB cable. |
| `auxiliary_usb_in` / `EL_USB_Auxiliary_In` | `(0.0855,−0.0355,0.0305)` | `(0,−1,0)` | Remaining free USB data port. |
| `camera_csi_in` / `EL_CSI_Camera_In` | `(−0.088,0.022,0.0338)` | `(0,1,0)` | Pi board FPC socket, inside case. This camera is CSI-connected, not USB-connected. |
| `camera_csi_case_exit` / `EL_CSI_Case_Exit` | `(−0.085,0.044,0.040)` | `(0,1,0)` | Route the flat ribbon from board anchor through this real rear opening, then along external supports. |
| `ambient_i2c_in` / `EL_Ambient_I2C_In` | `(0.0595,0.058,0.0295)` | `(1,0,0)` | Proposed RTC/shared-I2C breakout entry for ambient-sensor routing. |
| `pi_gpio_i2c` / `EL_Pi_GPIO_I2C` | `(−0.0865,0.0333,0.0395)` | `(0,0,1)` | Pi header reference; short RTC lead is already depicted. |
| `primary_usb_c_feed` / `EL_Primary_USB_C_Feed` | `(0.221,−0.021,0.165)` | `(−1,0,0)` | Captive DC cable exit on the independent Pi 27 W adapter; moves with UPS. |
| `pi_usb_c_in` / `EL_Pi_USB_C_In` | `(−0.087,−0.023,0.033)` | `(0,−1,0)` | Occupied Pi USB-C power port. |
| `pi_adapter_ac_in` / `EL_Pi_27W_AC_In` | `(0.242,−0.021,0.139)` | `(0,0,−1)` | Pi adapter's Type-A input blades, coincident with backup outlet 1. |
| `hub_adapter_ac_in` / `EL_Hub_Adapter_AC_In` | `(0.291,−0.021,0.139)` | `(0,0,−1)` | Hub adapter input blades, coincident with backup outlet 2. |
| `hub_adapter_dc_out` / `EL_Hub_Adapter_DC_Out` | `(0.291,0.007,0.158)` | `(0,1,0)` | Captive 12 V lead exit, moves with UPS. |
| `hub_dc_in` / `EL_Hub_DC_In` | `(0.024,0.0292,0.031)` | `(0,1,0)` | Occupied hub barrel-power input. |
| `ups_ac_in_plug` / `EL_UPS_AC_In` | `(0.4235,−0.073,0.008)` | `(−1,0,0)` | Tip of the existing resting mains plug; currently disconnected. |
| `ups_backup_out_1` / `EL_UPS_Backup_Out_1` | `(0.242,−0.021,0.139)` | `(0,0,1)` | First depicted backup outlet, for the separate Pi power supply. |
| `ups_backup_out_2` / `EL_UPS_Backup_Out_2` | `(0.291,−0.021,0.139)` | `(0,0,1)` | Second depicted backup outlet, for hub adapter input. |

All 15 positions were tested against actual Blender transforms within 1e−6 m at drops 0, −0.0255 and −0.0345 m. Both adapters now dock directly on separate UPS backup outlets. The two continuous DC cables terminate at their own adapter and device boots; there is no direct AC-to-USB-C line or invented inline USB-C coupler. External camera/sensor leads remain the master assembly's responsibility. The UPS's incoming mains plug remains visibly disconnected in the conceptual asset.

## Review evidence and limits

- `model-source/verify-electronics-power.py`: current successful Blender construction, budgets, 15 anchors, AC docking normals, DC endpoints and support-height checks.
- `model-source/electronics-power-validation.json`: full local/world coordinates and pose diagnostics.
- `work-notes/electronics-acquisition-review.png`: isolated assembled close view.
- `work-notes/electronics-exploded-review.png`: lid/cooler separated to inspect the board and connectors.
- `work-notes/electronics-ups-review.png`: separate UPS framing, generated by the review script.
- Review corrected cable smooth shading, literal PCB holes, source-correct thumb-drive geometry, lid/fan alignment, stepped upstream connector, and a real rear CSI exit. Test lighting is intentionally only 5 W / 3 W at this sub-metre scene scale; the first 100 W / 70 W studio test washed out the materials.

For the new full supply-chain review, see `electronics-power-review.md`. The model still requires the master's GLB/browser verification. Retain exported Empty names and extras. Structural glTF validation does not verify connector pinout, electronics correctness, usable clearances or measured instrument performance.
