# Proposed cage monitoring system

This is a reproducible design visualization for Yan Wang's September 2026 application to the Unitree Robotics Young Talent Sponsorship Program. The application is under review. It is not production CAD, a manufactured instrument, or a record of an experiment.

## Rebuild

Use Blender 5.2 LTS (verified with 5.2.1). Keep these source files together. From the containing project directory:

```
blender --background --factory-startup --python model-source/build_instrument.py -- --round 6 --render --samples 48
blender --background --factory-startup --python model-source/calibration.py -- --output model-output/calibration-round-6 --render --samples 20
```

The first command writes an editable `.blend`, a glTF 2.0 `.glb`, a geometry audit and a Cycles render to `model-output/round-6/`. Source units are metres, Z up. The glTF export is Y up. The second command builds the calibration accessories separately in `model-output/calibration-round-6/`.

## Files

- `build_instrument.py`: cage, wire lid, cameras, adjustable supports, external ambient/optional piezo sensing and routing.
- `geometry.py`: geometry helpers and physical materials.
- `refinements.py`: real frame slots and shaped adjustment knobs, with topology and envelope checks.
- `electronics.py`: acquisition assembly, power adapters, cables and connector anchors.
- `calibration.py`: independent calibration accessories.
- `electronics-manifest.md`, `electronics-power-review.md`, `calibration-assumptions.md`: sources, assumptions, connection coordinates and qualifications.
- `geometry-audit.json`: audit of the delivered main model.

## Source-based details

- Tecniplast 1264C body: 268 × 215 × 141 mm; the taper, wall thickness and wire-lid pattern are estimates.
- Camera Module 3 Wide NoIR PCB: 25 × 23.862 mm. Mounting holes are Ø2.2 mm on **21 × 12.5 mm** centers. The drawing's 14.5 mm dimension is from the upper row to the board edge, not the row-to-row spacing. The lens center is offset from the board center.
- PureThermal 3 PCB: 25.8 × 28.9 × 1.6 mm, Ø2.2 mm holes on 20.7 × 23.9 mm centers.
- Lepton core: 11.5 × 12.7 × 6.9 mm; 57° horizontal field. The 44° vertical field used for the visual overlay is a rounded aspect-ratio approximation.
- The external CSI ribbon is about 467.5 mm long, within the specified 500 mm allowance. This checks geometric length, not a production cable's bending or electrical performance.

Manufacturer documents are linked from the website's design notes; they are not bundled in this source archive. Camera carriers, enclosures, frame, cable guides and the overall layout are proposed rather than certified manufacturer CAD.

## Review history

The initial assembly and five subsequent revisions were reviewed. The first five versions used Blender 4.5.13; revision 6 was rebuilt with Blender 5.2.1.

1. Revised principal dimensions, real PCB/plate holes, ribbon routing and length, power adapters, grounded UPS/feet and product-render exposure.
2. Repaired planar shading after Boolean cuts, added sensor support, fixed semantic component selection/explosion and camera framing.
3. Corrected the Camera 3 hole and lens offsets from the original drawing, routed CSI clear of GPIO/PCB, supported the optional ADC, and added geometry-based grid-obstruction inspection. Fixed offscreen replay and readable mobile plots.
4. Seated camera insulating washers and fixing shafts, removed unused texture coordinates, refined fitting to visible parts, and verified the assembled/exploded reset behavior.
5. Connected the wire grid to its perimeter, replaced decorative column strips with four-sided T-slot geometry, added grip contours and real screw sockets, and increased cage-corner sampling. Removed micro-extrusion from printed labels. The main model has 119,745 triangles. Camera close-ups now show the downward-facing lenses; static 3D views no longer redraw for every replay update.

The 20 mm frame section, 6 mm slot mouths, 10 mm slot cavities, 4.2 mm central bore, and knob grip contours are design approximations. They are not manufacturer profiles or fabrication specifications. Camera poses, sourced component envelopes, and the 467.5 mm CSI route remain unchanged.

The model and browser checks do not establish manufacturing readiness, thermal accuracy, electrical compliance, or biological classification performance. Replay values are scripted examples, and sampled obstruction is a property of the illustrative grid geometry only.
