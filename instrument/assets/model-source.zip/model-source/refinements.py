"""Local mechanical detail pass for the proposed monitoring assembly.

Call ``apply_refinements(assembly, M)`` in Object mode, before
``join_by_material(assembly)``. This module neither rebuilds the scene nor
exports, saves or renders it. Target objects keep their identities, parenting,
transforms and component IDs. Only their mesh datablocks are replaced; the
eight old decorative slot strips are removed.

Blender 5.2-compatible APIs only: mesh data, BMesh, exact Boolean and bevel.
All section, bore and grip details below are proposed visualization geometry,
not manufacturer CAD, thread geometry or a fabrication specification.
"""

from __future__ import annotations

import json
import math
import re

import bpy
import bmesh
from mathutils import Matrix, Vector

from geometry import box, cylinder


_VERSION = "mechanical-detail-1"
_AUDIT_KEY = "mechanical_refinements_audit_json"
_COLUMN_SIZE = (0.020, 0.020, 0.400)
_MOUTH_WIDTH = 0.006
_MOUTH_RADIAL = (0.0080, 0.0106)  # Extends beyond the 10 mm outer face.
_CAVITY_WIDTH = 0.010
_CAVITY_RADIAL = (0.0060, 0.0083)  # 0.3 mm overlap with the slot mouth.
_BORE_DIAMETER = 0.0042
_COLUMN_EDGE_BREAK = 0.00012
_KNOB_RADIUS = 0.012
_KNOB_SEGMENTS = 48
_KNOB_LOBES = 12
_GRIP_RECESS = 0.0007
_KNOB_CHAMFER = 0.00045
_TOLERANCE = 0.000002  # 2 micrometres; used for mesh envelopes, not accuracy.


def _named_parts(parent, stem):
    pattern = re.compile(re.escape(stem) + r"(?:\.\d{3,})?$")
    return sorted(
        (o for o in parent.children if o.type == "MESH" and pattern.fullmatch(o.name)),
        key=lambda o: o.name,
    )


def _group(assembly, name):
    found = [o for o in assembly.children_recursive
             if o.type == "EMPTY" and
             (o.name == name or o.get("component_id") == name)]
    if len(found) != 1:
        raise ValueError(f"Expected one semantic Empty {name!r}; found {len(found)}.")
    return found[0]


def _bounds(mesh):
    if not mesh.vertices:
        raise ValueError("An empty mesh cannot be refined.")
    low = Vector(tuple(min(v.co[i] for v in mesh.vertices) for i in range(3)))
    high = Vector(tuple(max(v.co[i] for v in mesh.vertices) for i in range(3)))
    return low, high


def _mesh_stats(mesh):
    mesh.calc_loop_triangles()
    return {"vertices": len(mesh.vertices), "polygons": len(mesh.polygons),
            "triangles": len(mesh.loop_triangles)}


def _assembly_stats(assembly):
    totals = {"meshes": 0, "vertices": 0, "polygons": 0, "triangles": 0}
    for obj in assembly.children_recursive:
        if obj.type == "MESH":
            totals["meshes"] += 1
            for key, value in _mesh_stats(obj.data).items():
                totals[key] += value
    return totals


def _empty_signature(assembly):
    return sorted((o.name, str(o.get("component_id", "")),
                   o.parent.name if o.parent else "")
                  for o in [assembly, *assembly.children_recursive] if o.type == "EMPTY")


def _validate_solid(mesh):
    """Check connected, closed topology and orient faces; no collision claim."""
    bm = bmesh.new()
    try:
        bm.from_mesh(mesh)
        bmesh.ops.recalc_face_normals(bm, faces=list(bm.faces))
        nonmanifold = sum(not edge.is_manifold for edge in bm.edges)
        unseen = set(bm.verts)
        islands = 0
        while unseen:
            islands += 1
            stack = [unseen.pop()]
            while stack:
                vertex = stack.pop()
                for edge in vertex.link_edges:
                    other = edge.other_vert(vertex)
                    if other in unseen:
                        unseen.remove(other)
                        stack.append(other)
        volume = abs(bm.calc_volume(signed=True))
        if nonmanifold or islands != 1 or not math.isfinite(volume) or volume <= 0:
            raise ValueError(
                f"Invalid replacement solid {mesh.name!r}: "
                f"nonmanifold={nonmanifold}, islands={islands}, volume={volume}."
            )
        bm.to_mesh(mesh)
        mesh.update()
        return {"nonmanifold_edges": nonmanifold, "connected_components": islands,
                "volume_mm3": round(volume * 1e9, 3)}
    finally:
        bm.free()


def _remove_object_and_unused_mesh(obj):
    data = obj.data
    bpy.data.objects.remove(obj, do_unlink=True)
    if data and data.users == 0 and isinstance(data, bpy.types.Mesh):
        bpy.data.meshes.remove(data)


def _subtract(work, cutter):
    """Apply just this modifier under an explicit active-object context."""
    try:
        bpy.context.view_layer.update()
        modifier = work.modifiers.new("Proposed section cut", "BOOLEAN")
        modifier.operation = "DIFFERENCE"
        modifier.solver = "EXACT"
        modifier.object = cutter
        with bpy.context.temp_override(
            object=work, active_object=work,
            selected_objects=[work], selected_editable_objects=[work],
        ):
            bpy.ops.object.modifier_apply(modifier=modifier.name)
    finally:
        _remove_object_and_unused_mesh(cutter)


def _column_mesh(original):
    """Prepare a replacement off to the side without touching original data."""
    work = bpy.data.objects.new("__refine_column_work", original.data.copy())
    original.users_collection[0].objects.link(work)
    work.parent = original.parent
    work.matrix_parent_inverse = original.matrix_parent_inverse.copy()
    work.matrix_basis = original.matrix_basis.copy()
    low, high = _bounds(original.data)
    centre = (low + high) * 0.5
    cutter_length = _COLUMN_SIZE[2] + 0.004
    prepared = None
    try:
        for radial_axis in (0, 1):
            tangential_axis = 1 - radial_axis
            for sign in (-1, 1):
                for width, (inner, outer) in (
                    (_MOUTH_WIDTH, _MOUTH_RADIAL),
                    (_CAVITY_WIDTH, _CAVITY_RADIAL),
                ):
                    dimensions = [0.0, 0.0, cutter_length]
                    dimensions[radial_axis] = outer - inner
                    dimensions[tangential_axis] = width
                    position = centre.copy()
                    position[radial_axis] += sign * (inner + outer) * 0.5
                    cutter = box("__refine_slot_tool", dimensions, position,
                                 None, work, bevel=0)
                    _subtract(work, cutter)
        bore = cylinder("__refine_bore_tool", _BORE_DIAMETER * 0.5,
                        cutter_length, centre, None, work,
                        vertices=32, bevel=0)
        _subtract(work, bore)

        # A small, actual edge break after the cuts. Broad planar faces remain
        # flat; this avoids the Boolean smooth-normal rippling seen previously.
        bevel = work.modifiers.new("Proposed section edge break", "BEVEL")
        bevel.width = _COLUMN_EDGE_BREAK
        bevel.segments = 2
        bevel.limit_method = "ANGLE"
        bevel.angle_limit = math.radians(30)
        bevel.use_clamp_overlap = True
        with bpy.context.temp_override(
            object=work, active_object=work,
            selected_objects=[work], selected_editable_objects=[work],
        ):
            bpy.ops.object.modifier_apply(modifier=bevel.name)
        prepared = work.data
        for face in prepared.polygons:
            face.use_smooth = False
        return prepared
    finally:
        data = work.data
        bpy.data.objects.remove(work, do_unlink=True)
        if prepared is None and data.users == 0:
            bpy.data.meshes.remove(data)


def _knob_mesh(original, fallback_material):
    low, high = _bounds(original.data)
    centre = (low + high) * 0.5
    depth = high.z - low.z
    if abs((high.x - low.x) - 2 * _KNOB_RADIUS) > _TOLERANCE or \
       abs((high.y - low.y) - 2 * _KNOB_RADIUS) > _TOLERANCE:
        raise ValueError(f"{original.name}: expected a 12 mm-radius local-Z knob.")
    expected_depth = 0.006 if original.name.startswith("Clamp tightening knob") else 0.008
    if abs(depth - expected_depth) > _TOLERANCE:
        raise ValueError(f"{original.name}: unexpected local depth {depth * 1000:.3f} mm.")

    # Four rings, 48 vertices each: twelve rounded grip lobes are part of ONE
    # solid. Maxima at the X/Y axes preserve the original 24 mm XY envelope.
    rings = [(-depth / 2, _KNOB_CHAMFER),
             (-depth / 2 + _KNOB_CHAMFER, 0),
             (depth / 2 - _KNOB_CHAMFER, 0),
             (depth / 2, _KNOB_CHAMFER)]
    vertices = []
    for z, inset in rings:
        for i in range(_KNOB_SEGMENTS):
            angle = math.tau * i / _KNOB_SEGMENTS
            radius = (_KNOB_RADIUS - inset -
                      _GRIP_RECESS * (1 - math.cos(_KNOB_LOBES * angle)) / 2)
            vertices.append(tuple(centre + Vector(
                (radius * math.cos(angle), radius * math.sin(angle), z))))
    faces = []
    for ring in range(3):
        for i in range(_KNOB_SEGMENTS):
            j = (i + 1) % _KNOB_SEGMENTS
            faces.append((ring * _KNOB_SEGMENTS + i, ring * _KNOB_SEGMENTS + j,
                          (ring + 1) * _KNOB_SEGMENTS + j,
                          (ring + 1) * _KNOB_SEGMENTS + i))
    faces.extend([tuple(reversed(range(_KNOB_SEGMENTS))),
                  tuple(range(3 * _KNOB_SEGMENTS, 4 * _KNOB_SEGMENTS))])
    mesh = bpy.data.meshes.new(original.data.name + " | proposed grip")
    try:
        mesh.from_pydata(vertices, [], faces)
        mesh.update()
        if original.data.materials:
            for material in original.data.materials:
                mesh.materials.append(material)
        else:
            mesh.materials.append(fallback_material)
        for face in mesh.polygons:
            face.use_smooth = len(face.vertices) == 4
        return mesh
    except Exception:
        bpy.data.meshes.remove(mesh)
        raise


def _check_envelope(original, replacement):
    old_bounds = _bounds(original.data)
    new_bounds = _bounds(replacement)
    error = max(abs(a[i] - b[i]) for a, b in zip(old_bounds, new_bounds) for i in range(3))
    if error > _TOLERANCE:
        raise ValueError(f"{original.name}: replacement changes its envelope by {error * 1000:.4f} mm.")
    return round(error * 1000, 6)


def apply_refinements(assembly, M):
    """Replace only two columns, six knobs and eight decorative slot strips.

    Return a JSON-serializable geometry audit. All new meshes are built and
    checked before any original mesh is swapped or strip removed. Calling
    again on an already-refined assembly returns its saved historical audit.
    The caller owns full-scene validation, rendering and file output.
    """
    if bpy.context.mode != "OBJECT":
        raise RuntimeError("apply_refinements must run in Object mode before material joining.")
    if assembly.type != "EMPTY":
        raise ValueError("The assembly root must be its existing semantic Empty.")
    if assembly.get(_AUDIT_KEY):
        audit = json.loads(assembly[_AUDIT_KEY])
        if audit.get("version") != _VERSION:
            raise ValueError("A different refinement version is already installed.")
        audit["already_applied"] = True
        return audit
    support, mounts = _group(assembly, "Support"), _group(assembly, "Camera mounts")
    columns = _named_parts(support, "2020 support extrusion")
    strips = _named_parts(support, "Extrusion T slot")
    clamp_knobs = _named_parts(mounts, "Clamp tightening knob")
    arm_knobs = _named_parts(mounts, "Arm lock wheel")
    actual = (len(columns), len(strips), len(clamp_knobs), len(arm_knobs))
    if actual != (2, 8, 2, 4):
        raise ValueError(
            "Run before join_by_material on the unrefined source assembly: "
            f"expected columns/strips/clamp knobs/arm wheels=(2,8,2,4), got {actual}."
        )
    targets = columns + clamp_knobs + arm_knobs
    for obj in targets:
        if obj.modifiers:
            raise ValueError(f"{obj.name}: apply source modifiers before this refinement pass.")
        if any(abs(s - 1.0) > 1e-6 for s in obj.scale):
            raise ValueError(f"{obj.name}: expected the source's applied unit scale.")
    for column in columns:
        low, high = _bounds(column.data)
        if any(abs((high - low)[i] - _COLUMN_SIZE[i]) > _TOLERANCE for i in range(3)):
            raise ValueError(f"{column.name}: expected a 20 x 20 x 400 mm local envelope.")
    if "black" not in M:
        raise ValueError("The existing material palette must supply M['black'].")

    bpy.context.view_layer.update()
    before = _assembly_stats(assembly)
    semantic_before = _empty_signature(assembly)
    matrices = {obj: obj.matrix_world.copy() for obj in targets}
    selected_names = [obj.name for obj in bpy.context.selected_objects]
    active = bpy.context.view_layer.objects.active
    active_name = active.name if active else None
    prepared = []
    committed = False
    try:
        for obj in targets:
            new_mesh = _column_mesh(obj) if obj in columns else _knob_mesh(obj, M["black"])
            prepared.append((obj, new_mesh))
            topology = _validate_solid(new_mesh)
            error = _check_envelope(obj, new_mesh)
            new_mesh["proposed_geometry"] = True
            new_mesh["refinement_version"] = _VERSION
            # Validation details are recorded while old and new data coexist.
            new_mesh["refinement_metrics_json"] = json.dumps({
                "name": obj.name, "before": _mesh_stats(obj.data),
                "after": _mesh_stats(new_mesh), "topology": topology,
                "max_envelope_error_mm": error,
            })
        part_audits = [json.loads(mesh["refinement_metrics_json"]) for _, mesh in prepared]
        old_meshes = []
        for obj, mesh in prepared:
            old_meshes.append(obj.data)
            obj.data = mesh
        # No semantic object is recreated: object names, axes, custom IDs and
        # existing parents therefore remain attached to the original objects.
        committed = True
        for strip in strips:
            _remove_object_and_unused_mesh(strip)
        for mesh in old_meshes:
            if mesh.users == 0:
                bpy.data.meshes.remove(mesh)
        bpy.context.view_layer.update()
        if _empty_signature(assembly) != semantic_before:
            raise RuntimeError("Unexpected semantic Empty or component-ID change.")
        if any(max(abs(obj.matrix_world[r][c] - matrix[r][c])
                   for r in range(4) for c in range(4)) > 1e-8
               for obj, matrix in matrices.items()):
            raise RuntimeError("Unexpected target transform change.")

        audit = {
            "version": _VERSION, "already_applied": False,
            "blender_version": bpy.app.version_string,
            "before": before, "after": _assembly_stats(assembly),
            "columns": {
                "count": len(columns), "removed_decorative_strips": len(strips),
                "outer_mm": [20, 20, 400], "slots_per_column": 4,
                "slot_mouth_width_mm": 6, "internal_cavity_width_mm": 10,
                "mouth_radial_range_mm": [8.0, 10.6],
                "cavity_radial_range_mm": [6.0, 8.3],
                "central_through_bore_diameter_mm": 4.2,
                "edge_break_mm": 0.12,
                "minimum_nominal_diagonal_web_mm": round(math.sqrt(2), 3),
                "parts": part_audits[:len(columns)],
            },
            "knobs": {
                "count": len(clamp_knobs) + len(arm_knobs),
                "clamp_count": len(clamp_knobs), "arm_wheel_count": len(arm_knobs),
                "outer_radius_mm": 12, "clamp_depth_mm": 6, "arm_depth_mm": 8,
                "circumferential_segments": 48, "grip_lobes": 12,
                "radial_grip_recess_mm": 0.7, "axial_radial_chamfer_mm": 0.45,
                "parts": part_audits[len(columns):],
            },
            "semantic_empties_preserved": True,
            "semantic_empty_count": len(semantic_before),
            "target_transforms_preserved": True,
            "limits": [
                "Proposed profile and grip geometry; not SmallRig or extrusion manufacturer CAD.",
                "Nominal web dimension is a cross-section estimate before the small edge break.",
                "Bore is unthreaded; no thread, strength, clamping-load or fabrication validation.",
                "Topology/envelope checks are not full assembly collision or fit validation.",
                "Other hardware, camera optics, cables and semantic group IDs were not changed.",
            ],
        }
        assembly[_AUDIT_KEY] = json.dumps(audit, ensure_ascii=False)
        return audit
    finally:
        if not committed:
            for _, mesh in prepared:
                if mesh.users == 0:
                    bpy.data.meshes.remove(mesh)
        # The stock geometry helpers change the active selection. Restore the
        # caller's surviving objects; intentionally removed strips stay removed.
        bpy.ops.object.select_all(action="DESELECT")
        for name in selected_names:
            obj = bpy.data.objects.get(name)
            if obj is not None:
                obj.select_set(True)
        bpy.context.view_layer.objects.active = bpy.data.objects.get(active_name) if active_name else None
