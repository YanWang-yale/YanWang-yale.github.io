"""Independent calibration accessory concept, metres and Z-up.

Import without side effects and call build_calibration(parent=None).
Every unsourced part shape and all assembly positions are proposed approximations.
Run directly with Blender to export a separate GLB; see calibration-assumptions.md.
"""
from pathlib import Path
import argparse
import json
import math
import sys

import bpy
from mathutils import Vector

HERE = Path(__file__).resolve().parent
if str(HERE) not in sys.path:
    sys.path.insert(0, str(HERE))
from geometry import material, empty, box, cylinder, rod, screw, rounded_ring, finish, join_by_material


def label(name,text,loc,size,mat,parent=None,rotation=(0,0,0)):
    """Flat printed markings: no excessive micro-extrusion geometry."""
    data=bpy.data.curves.new(name,'FONT');data.body=text;data.size=size
    data.extrude=0;data.align_x='CENTER';data.align_y='CENTER';data.resolution_u=2
    obj=bpy.data.objects.new(name,data);bpy.context.collection.objects.link(obj)
    obj.location=loc;obj.rotation_euler=rotation;obj.parent=parent;data.materials.append(mat)
    bpy.ops.object.select_all(action='DESELECT');obj.select_set(True)
    bpy.context.view_layer.objects.active=obj;bpy.ops.object.convert(target='MESH');obj.select_set(False)
    return obj


def _part(name, parent, description):
    obj = empty(name, parent, description=description)
    obj['geometry_basis'] = 'proposed approximation; not manufacturer CAD'
    obj['component_id'] = name
    return obj


def _cable(name, points, radius, mat, parent):
    # Small cables use economical bevel sampling; geometry remains genuinely round.
    bpy.ops.object.select_all(action='DESELECT')
    data=bpy.data.curves.new(name,'CURVE');data.dimensions='3D';data.resolution_u=6
    data.bevel_depth=radius;data.bevel_resolution=2
    spline=data.splines.new('BEZIER');spline.bezier_points.add(len(points)-1)
    for point,co in zip(spline.bezier_points,points):
        point.co=co;point.handle_left_type='AUTO';point.handle_right_type='AUTO'
    obj=bpy.data.objects.new(name,data);bpy.context.collection.objects.link(obj)
    obj.data.materials.append(mat);obj.parent=parent
    bpy.context.view_layer.objects.active=obj;obj.select_set(True)
    bpy.ops.object.convert(target='MESH');obj=bpy.context.object;obj.select_set(False)
    obj['geometry_basis'] = 'proposed approximation; routing illustrative'
    return obj


def _tub_shell(parent, mat):
    # Hollow molded container; all dimensions are deliberately labelled estimates.
    # The named 12 qt capacity is from the proposal, not calculated from this mesh.
    specs = [(.241, .221, .022, .032), (.245, .225, .023, .037),
             (.271, .251, .028, .218), (.280, .260, .030, .222),
             (.280, .260, .030, .227), (.263, .243, .025, .227),
             (.263, .243, .025, .218), (.237, .217, .020, .040)]
    verts = []
    for spec in specs:
        verts.extend((x-.137, y+.030, z) for x, y, z in rounded_ring(*spec))
    n = 32
    faces = []
    for j in range(len(specs)-1):
        for i in range(n):
            faces.append((j*n+i, j*n+(i+1)%n, (j+1)*n+(i+1)%n, (j+1)*n+i))
    faces.extend([tuple(reversed(range(n))), tuple(range((len(specs)-1)*n, len(specs)*n))])
    mesh = bpy.data.meshes.new('CAL molded bath shell mesh')
    mesh.from_pydata(verts, [], faces)
    mesh.update()
    obj = bpy.data.objects.new('CAL Cambro 12 qt representative shell', mesh)
    bpy.context.collection.objects.link(obj)
    finish(obj, obj.name, mat, parent, bevel=.0005)
    obj['geometry_basis'] = 'proposed approximation: 280 x 260 x 195 mm envelope; exact Cambro SKU not given'
    obj['capacity_label_only'] = '12 US qt from proposal BOM; rendered fill is illustrative'
    return obj


def build_calibration(parent=None):
    """Return a self-contained EMPTY root, local floor z=0, units metres.

    This function neither clears the scene nor touches the main instrument.
    Move/rotate/hide CALIBRATION_ACCESSORIES and all descendants follow.
    """
    root = empty('CALIBRATION_ACCESSORIES', parent)
    root['description'] = 'Independent bench reference and transfer-calibration accessories. No connection to the cage monitor.'
    root['design_status'] = 'proposed approximation; no purchased, assembled or validated hardware claimed'
    root['units'] = 'metres'
    root['up_axis_source'] = 'Z'
    root['source_documents'] = 'September 3, 2026 final funding application and implementation plan; see funding-instrument-evidence.md'
    root['scope'] = 'Calibration branch only: water bath, circulator, sealed target, contact PT100 and MAX31865 readout lead'

    m = {
        'white': material('CAL satin porcelain coat', (.66,.73,.78), .22,.3),
        'metal': material('CAL brushed aluminium', (.44,.50,.55), .88,.29),
        'steel': material('CAL stainless probe and sleeve', (.61,.66,.70), .94,.21),
        'black': material('CAL graphite polymer', (.024,.032,.044), .05,.39),
        'rubber': material('CAL silicone cable', (.013,.019,.024), 0,.64),
        'target': material('CAL matte black reference surface', (.027,.029,.030), 0,.84),
        'mark': material('CAL ivory instrument markings', (.85,.90,.91), 0,.6),
        'accent': material('CAL reference channel sage', (.065,.30,.29), .16,.4),
        'pcb': material('CAL MAX31865 representative solder mask', (.023,.13,.24), .07,.4),
        'green': material('CAL screw terminal polymer', (.043,.31,.22), .03,.43),
        'gold': material('CAL connector plated contacts', (.62,.40,.10), .85,.24),
        'red': material('CAL PT100 red wire', (.45,.026,.026), 0,.51),
        'wirewhite': material('CAL PT100 white wire', (.65,.68,.66), 0,.55),
        'clear': material('CAL representative clear bath polymer', (.91,.97,.98), 0,.095,.96,1.50),
        'water': material('CAL illustrative bath water', (.69,.89,.93), 0,.045,.83,1.333),
        'screen': material('CAL unpowered display lens', (.008,.021,.025), .20,.15),
    }

    support = _part('CAL_01_Independent_tray', root, 'Compact removable bench tray and cable guides; designed accessories, not proposal purchased parts.')
    box('CAL tray top', (.590,.366,.012), (0,0,.025), m['white'], support, .008)
    box('CAL front identification rail', (.571,.009,.022), (0,-.181,.024), m['black'], support, .002)
    label('CAL tray identity', 'CALIBRATION  /  BENCH REFERENCE', (0,-.186,.026), .0055, m['mark'], support, (math.pi/2,0,0))
    for x in [-.249,.249]:
        for y in [-.138,.138]:
            cylinder('CAL silicone foot', .011,.018,(x,y,.009),m['rubber'],support,24,bevel=.001)
    for x in [-.270,.270]:
        screw('CAL tray fixing',(x,-.148,.032),m['steel'],support,radius=.0022)

    bath = _part('CAL_02_Cambro_12qt_bath', root, 'P38 Cambro 12 qt bath container. Capacity/model family sourced; silhouette and fill height proposed approximations.')
    bath['source_bom'] = 'P38; implementation plan pp9-11,16'
    _tub_shell(bath,m['clear'])
    water_verts=[]
    for spec in [(.232,.212,.019,.042),(.251,.231,.024,.167)]:
        water_verts.extend((x-.137,y+.030,z) for x,y,z in rounded_ring(*spec))
    water_faces=[(i,(i+1)%32,32+(i+1)%32,32+i) for i in range(32)]
    water_faces.extend([tuple(reversed(range(32))),tuple(range(32,64))])
    water_mesh=bpy.data.meshes.new('CAL tapered illustrative water volume')
    water_mesh.from_pydata(water_verts,[],water_faces);water_mesh.update()
    water_obj=bpy.data.objects.new('CAL illustrative water volume',water_mesh)
    bpy.context.collection.objects.link(water_obj);finish(water_obj,water_obj.name,m['water'],bath)
    # A still bath has a flat free surface, without smooth-normal bulging/refraction.
    for poly in water_mesh.polygons[-2:]:poly.use_smooth=False
    # Molded grip lugs at the left/right side stay outside the bath opening.
    for x in [-.283,.009]:
        box('CAL molded bath handle',(.020,.066,.007),(x,.030,.221),m['clear'],bath,.003)
    box('CAL bath capacity label',(.041,.0006,.015),(-.193,-.093,.177),m['mark'],bath,.001)
    label('CAL bath capacity','12 QT',(-.193,-.0935,.177),.0056,m['accent'],bath,(math.pi/2,0,0))
    # Sparse marks suggest container graduations without inventing numeric levels.
    for z in [.071,.099,.127,.155]:
        box('CAL unnumbered fill graduation',(.015,.0004,.0006),(-.064,-.092,z),m['accent'],bath,0)

    circulator = _part('CAL_03_ISV100W_circulator',root,'P23 Inkbird ISV-100W bath circulator. Standalone calibration bath accessory; envelope, controls and clamp are representative, not manufacturer CAD.')
    circulator['source_bom'] = 'P23; implementation plan p16'
    x,y = -.185,.100
    cylinder('CAL circulator steel immersion sleeve',.029,.155,(x,y,.151),m['steel'],circulator,48,bevel=.0015)
    cylinder('CAL circulator lower cap',.0298,.013,(x,y,.077),m['black'],circulator,40,bevel=.002)
    # Geometric dark recesses indicate water intake slots, not operational flow arrows.
    for i in range(12):
        a=2*math.pi*i/12
        slot=box('CAL representative intake recess',(.0022,.008,.028),
                 (x+.0293*math.cos(a),y+.0293*math.sin(a),.102),m['black'],circulator,.0007)
        slot.rotation_euler.z=a
    cylinder('CAL circulator upper polymer body',.042,.145,(x,y,.301),m['black'],circulator,48,bevel=.004)
    cylinder('CAL circulator collar',.043,.008,(x,y,.231),m['accent'],circulator,48,bevel=.001)
    cylinder('CAL control head shoulder',.044,.020,(x,y,.378),m['black'],circulator,48,bevel=.003)
    cylinder('CAL unpowered control face',.0335,.0015,(x,y,.3885),m['screen'],circulator,48,bevel=.0003)
    box('CAL circulator identity panel',(.041,.002,.018),(x,y-.041,.302),m['black'],circulator,.002)
    label('CAL circulator identifier','ISV-100W',(x,y-.0421,.302),.0046,m['mark'],circulator,(math.pi/2,0,0))
    # Raised top markings remain unlit; they are not a simulated measurement.
    label('CAL circulator display blank','-- --',(x,y+.003,.3894),.009,m['accent'],circulator)
    for dx in [-.014,.014]:
        cylinder('CAL control touch pad',.004,.0002,(x+dx,y-.018,.3894),m['black'],circulator,16,bevel=0)
    # Short clamp bridges the rear wall; tightening screw stays on the outside.
    box('CAL bath clamp bridge',(.029,.087,.014),(x,.146,.255),m['black'],circulator,.003)
    box('CAL bath clamp outer jaw',(.032,.015,.052),(x,.187,.235),m['black'],circulator,.003)
    rod('CAL clamp adjustment stem',(x,.182,.231),(x,.211,.231),.003,m['steel'],circulator,20)
    cylinder('CAL clamp thumbscrew',.012,.007,(x,.214,.231),m['black'],circulator,32,(0,1,0),bevel=.001)
    _cable('CAL circulator independent mains lead',[(x,.130,.305),(-.226,.170,.301),(-.275,.201,.145),
             (-.253,.223,.052),(-.209,.226,.040),(-.150,.220,.040)],.0028,m['rubber'],circulator)
    box('CAL parked unconnected mains plug',(.033,.026,.018),(-.131,.220,.040),m['black'],circulator,.003)
    for px in [-.122,-.113]:
        box('CAL parked plug blade',(.002,.005,.012),(px,.220,.052),m['steel'],circulator,.0003)

    target = _part('CAL_04_Target_reference_plane',root,'Matte sealed warm-water surrogate and adjacent coplanar contact reference, with four registration marks. Geometry and support designed for this concept.')
    target['source_bom'] = 'P37 and implementation plan pp13-14,16'
    target['temperature_status'] = 'No measured or simulated temperature asserted'
    # Front-accessible two-post mount is an illustrative stand, not an optical bench purchase.
    box('CAL target stand foot',(.167,.081,.008),(.151,.032,.036),m['metal'],target,.004)
    for px in [.092,.210]:
        cylinder('CAL target stand riser',.007,.069,(px,.066,.074),m['metal'],target,24,bevel=.001)
        screw('CAL target stand fixing',(px,.015,.041),m['steel'],target,radius=.0023)
    carrier=box('CAL reference carrier',(.190,.120,.012),(.153,.065,.118),m['black'],target,.003)
    # A real clearance in the carrier lets the rear-contact probe pass through.
    bpy.ops.mesh.primitive_cylinder_add(vertices=24,radius=.0036,depth=.020,location=(.211,.065,.118))
    clearance=bpy.context.object
    clearance.parent=target
    bpy.context.view_layer.update()
    modifier=carrier.modifiers.new('Proposed probe clearance','BOOLEAN')
    modifier.operation='DIFFERENCE';modifier.solver='EXACT';modifier.object=clearance
    bpy.context.view_layer.objects.active=carrier;bpy.ops.object.modifier_apply(modifier=modifier.name)
    bpy.data.objects.remove(clearance,do_unlink=True)
    box('CAL sealed warm-water target',(.111,.078,.024),(.122,.065,.136),m['target'],target,.010)
    # Flat face, not a glossy screen; target and reference surface finish at z=.149.
    box('CAL matte target face',(.098,.065,.001),(.122,.065,.1485),m['target'],target,.002)
    # Open-bottom perimeter supports keep the probe in real contact with the back.
    for py in [.0325,.0975]:
        box('CAL reference backing edge',(.043,.005,.022),(.211,py,.137),m['black'],target,.001)
    for px in [.192,.230]:
        box('CAL reference backing edge',(.005,.060,.022),(px,.065,.137),m['black'],target,.001)
    box('CAL coplanar reference surface',(.043,.070,.001),(.211,.065,.1485),m['target'],target,.001)
    cylinder('CAL sealed target recessed fill cap',.007,.004,(.087,.023,.134),m['black'],target,24,(0,-1,0),bevel=.001)
    # Four geometric checker fiducials on corner tabs share the target plane.
    for i,(px,py) in enumerate([(.065,.016),(.241,.016),(.065,.114),(.241,.114)],1):
        box('CAL fiducial tab',(.014,.014,.024),(px,py,.136),m['black'],target,.001)
        box(f'CAL registration mark {i}',(.010,.010,.00025),(px,py,.1492),m['mark'],target,0)
        for dx,dy in [(-.0025,-.0025),(.0025,.0025)]:
            box(f'CAL fiducial {i} dark quadrant',(.005,.005,.00012),(px+dx,py+dy,.1494),m['target'],target,0)
    label('CAL target channel','TARGET  /  REFERENCE',(.151,-.001,.119),.0042,m['mark'],target,(math.pi/2,0,0))

    pt100 = _part('CAL_05_PT100_three_wire_reference',root,'P10 three-wire contact PT100. Tip contacts the back of the reference surface; this is not animal core temperature.')
    pt100['source_bom'] = 'P10; implementation plan p9,16'
    # A separate reference skin/backing leaves a visible contact-probe route.
    cylinder('CAL PT100 stainless sheath',.0022,.032,(.211,.065,.132),m['steel'],pt100,24,bevel=.0004)
    cylinder('CAL probe compression collar',.004,.005,(.211,.065,.112),m['black'],pt100,24,bevel=.0006)
    # End of metal sheath meets z=.148, the back of the 1 mm reference skin.
    _cable('CAL PT100 three-core jacket',[(.211,.065,.109),(.232,.054,.094),(.240,.010,.065),
             (.231,-.026,.045),(.201,-.057,.041),(.163,-.067,.047)],.00165,m['rubber'],pt100)
    for i,(wiremat,endx) in enumerate([(m['red'],.151),(m['red'],.158),(m['wirewhite'],.165)]):
        _cable('CAL PT100 red lead' if i<2 else 'CAL PT100 white lead',
               [(.163+(i-1)*.0011,-.067,.047),(endx,-.077,.050),(endx,-.088,.053)],
               .00055,wiremat,pt100)

    readout = _part('CAL_06_MAX31865_readout',root,'P11 MAX31865 interface board with representative three-wire terminal and SPI readout lead; no independent logger/display is invented.')
    readout['source_bom'] = 'P11; implementation plan p9'
    box('CAL readout carrier',(.105,.067,.007),(.171,-.110,.036),m['white'],readout,.004)
    box('CAL MAX31865 representative PCB',(.053,.032,.0016),(.166,-.108,.046),m['pcb'],readout,.001)
    for px in [.142,.190]:
        for py in [-.121,-.095]:
            cylinder('CAL board nylon spacer',.002,.007,(px,py,.041),m['black'],readout,16,bevel=.0004)
            screw('CAL board mounting screw',(px,py,.0478),m['steel'],readout,radius=.0015)
    box('CAL RTD terminal block',(.026,.008,.007),(.158,-.090,.050),m['green'],readout,.001)
    for px in [.151,.158,.165]:
        cylinder('CAL RTD screw terminal',.0013,.0006,(px,-.090,.054),m['steel'],readout,16,bevel=0)
    box('CAL MAX31865 IC',(.0058,.0058,.0014),(.161,-.108,.0475),m['black'],readout,.00025)
    for j in range(7):
        box('CAL representative surface passive',(.0022,.0011,.00065),(.149+j*.005,-.117,.0471),m['black'],readout,.00012)
    box('CAL SPI header housing',(.007,.021,.004),(.190,-.106,.049),m['black'],readout,.0008)
    for py in [-.114,-.110,-.106,-.102,-.098]:
        box('CAL SPI pin',(.003,.0006,.0006),(.194,py,.049),m['gold'],readout,0)
    box('CAL readout header plug',(.010,.022,.006),(.200,-.106,.0495),m['rubber'],readout,.001)
    _cable('CAL independent SPI readout lead',[(.205,-.106,.0495),(.233,-.109,.044),
             (.255,-.125,.039),(.296,-.138,.039),(.335,-.120,.039)],.0020,m['rubber'],readout)
    box('CAL unconnected readout plug',(.026,.012,.009),(.344,-.118,.039),m['black'],readout,.0015)
    for py in [-.122,-.119,-.116,-.113]:
        box('CAL readout contact',(.0005,.001,.004),(.3573,py,.039),m['gold'],readout,0)
    label('CAL readout identity','PT100  /  MAX31865',(.165,-.139,.036),.0036,m['accent'],readout)
    label('CAL readout destination','READOUT',(.251,-.159,.032),.0033,m['accent'],readout)

    # Mark all generated geometry, including any unlabeled small fastener.
    for obj in root.children_recursive:
        if obj.type == 'MESH':
            if 'geometry_basis' not in obj:
                obj['geometry_basis'] = 'proposed approximation; not manufacturer CAD'
    root['group_ids'] = ','.join(child.name for child in root.children)
    return root


def _audit(root):
    meshes=[obj for obj in root.children_recursive if obj.type=='MESH']
    triangles=0
    points=[]
    bpy.context.view_layer.update()
    for obj in meshes:
        obj.data.calc_loop_triangles()
        triangles+=len(obj.data.loop_triangles)
        points.extend(obj.matrix_world @ Vector(p) for p in obj.bound_box)
    bounds=[[min(p[i] for p in points),max(p[i] for p in points)] for i in range(3)]
    return {'triangles':triangles,'meshes':len(meshes),'bounds_m':bounds,'blender_version':bpy.app.version_string,
            'units':'metres','source_up_axis':'Z','glb_up_axis':'Y (standard glTF conversion)',
            'geometry_status':'proposed approximation','components':[c.name for c in root.children]}


def _studio(root,out,samples):
    scene=bpy.context.scene
    floor=material('CAL studio floor',(.66,.72,.76),0,.62)
    box('CAL studio ground',(200,200,.020),(0,0,-.011),floor,None,0)
    scene.world.use_nodes=True
    scene.world.node_tree.nodes['Background'].inputs[0].default_value=(.66,.74,.82,1)
    scene.world.node_tree.nodes['Background'].inputs[1].default_value=.22
    for name,loc,energy,size,color in [('CAL key',(-.5,-.7,1.0),7,.7,(1,.95,.89)),
                                     ('CAL rim',(.5,.35,.85),8,.65,(.82,.91,1)),
                                     ('CAL top',(-.15,.3,1.0),4,.6,(1,1,1))]:
        data=bpy.data.lights.new(name,'AREA');data.energy=energy;data.shape='DISK';data.size=size;data.color=color
        obj=bpy.data.objects.new(name,data);bpy.context.collection.objects.link(obj);obj.location=loc
        obj.rotation_euler=(Vector((0,0,.16))-obj.location).to_track_quat('-Z','Y').to_euler()
    data=bpy.data.cameras.new('CAL product camera')
    cam=bpy.data.objects.new('CAL product camera',data);bpy.context.collection.objects.link(cam)
    cam.location=(.86,-1.05,.90)
    cam.rotation_euler=(Vector((.015,.025,.175))-cam.location).to_track_quat('-Z','Y').to_euler()
    data.type='ORTHO';data.ortho_scale=.87;data.lens=55;scene.camera=cam
    scene.render.engine='CYCLES';scene.cycles.samples=samples;scene.cycles.use_denoising=True
    scene.cycles.max_bounces=10;scene.cycles.transmission_bounces=8
    scene.render.resolution_x=1600;scene.render.resolution_y=1250;scene.render.resolution_percentage=100
    scene.view_settings.view_transform='AgX';scene.render.image_settings.file_format='PNG'
    scene.render.filepath=str(out/'calibration-preview.png')
    bpy.ops.wm.save_as_mainfile(filepath=str(out/'calibration-accessories.blend'))
    bpy.ops.render.render(write_still=True)


if __name__=='__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('--output',type=Path,default=HERE.parent/'model-output'/'calibration')
    parser.add_argument('--render',action='store_true')
    parser.add_argument('--samples',type=int,default=32)
    args=parser.parse_args(sys.argv[sys.argv.index('--')+1:] if '--' in sys.argv else [])
    args.output.mkdir(parents=True,exist_ok=True)
    bpy.ops.object.select_all(action='SELECT');bpy.ops.object.delete(use_global=False)
    scene=bpy.context.scene;scene.unit_settings.system='METRIC';scene.unit_settings.scale_length=1.0
    assembly=build_calibration()
    join_by_material(assembly)
    audit=_audit(assembly)
    assert audit['triangles']<30000, f'Calibration triangle limit exceeded: {audit}'
    (args.output/'calibration-audit.json').write_text(json.dumps(audit,indent=2),encoding='utf-8')
    bpy.ops.object.select_all(action='DESELECT');assembly.select_set(True)
    for obj in assembly.children_recursive:obj.select_set(True)
    bpy.context.view_layer.objects.active=assembly
    bpy.ops.export_scene.gltf(filepath=str(args.output/'calibration-accessories.glb'),
        export_format='GLB',use_selection=True,export_yup=True,export_extras=True,
        export_cameras=False,export_lights=False,export_materials='EXPORT',export_apply=True,export_texcoords=False)
    if args.render:
        _studio(assembly,args.output,args.samples)
    else:
        bpy.ops.wm.save_as_mainfile(filepath=str(args.output/'calibration-accessories.blend'))
    print('CALIBRATION_BUILD_COMPLETE',json.dumps(audit),flush=True)
