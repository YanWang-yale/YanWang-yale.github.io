"""Reproducible proposed assembly. Blender 5.2 LTS, metres, Z-up."""
from pathlib import Path
import bpy, math, sys, json, argparse
from mathutils import Vector
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE))
from geometry import *

ROOT=HERE.parent
parser=argparse.ArgumentParser()
parser.add_argument('--round',type=int,default=1)
parser.add_argument('--render',action='store_true')
parser.add_argument('--samples',type=int,default=48)
args=parser.parse_args(sys.argv[sys.argv.index('--')+1:] if '--' in sys.argv else [])
OUT=ROOT/'model-output'/f'round-{args.round}'
OUT.mkdir(parents=True,exist_ok=True)
bpy.ops.object.select_all(action='SELECT');bpy.ops.object.delete(use_global=False)
scene=bpy.context.scene;scene.unit_settings.system='METRIC';scene.unit_settings.length_unit='MILLIMETERS'

M={
 'metal':material('Bead-blasted anodized aluminium',(.40,.47,.53),.85,.29),
 'steel':material('Brushed stainless steel',(.57,.63,.68),.92,.22),
 'black':material('Textured graphite polymer',(.027,.036,.047),.05,.38),
 'rubber':material('Rubber cable jacket',(.014,.021,.03),0,.61),
 'white':material('Porcelain white powder coat',(.74,.79,.83),.12,.33),
 'blue':material('Deep blue panel',(.045,.12,.22),.22,.31),
 'teal':material('Channel indicator teal',(.045,.46,.43),.2,.31),
 'orange':material('Thermal channel copper',(.78,.28,.08),.25,.32),
 'pcb':material('PCB solder mask',(.021,.21,.13),.05,.4),
 'gold':material('Connector gold',(.69,.46,.1),.8,.23),
 'lens':material('Coated lens glass',(.025,.053,.062),.48,.075),
 'plastic':material('Polycarbonate 2.5 mm',(.91,.975,1),0,.075,1,1.586),
 'target':material('Matte calibration target',(.075,.075,.077),0,.7),
 'mark':material('Instrument white lettering',(.82,.89,.92),0,.52)
}
assembly=empty('Cage monitor | proposed engineering assembly')
assembly['design_status']='Proposed instrument design, not manufactured or experimentally validated.'
assembly['units']='metres';assembly['revision']=args.round
assembly['source_documents']='September 2026 funding application and implementation plan'
base=empty('Support',assembly,description='Designed rigid bench base and camera support; mounting geometry is a proposed design.')
box('Machined base plate',(.66,.37,.012),(.045,0,.02),M['white'],base,.008)
box('Front fascia',(.642,.012,.023),(.045,-.18,.025),M['blue'],base,.003)
label('Rig name','HYPOMETABOLISM  /  MONITORING RIG',(.045,-.187,.026),.007,M['mark'],base,(math.pi/2,0,0))
label('Revision','PROPOSED ASSEMBLY   /   01',(.20,-.187,.015),.0032,M['mark'],base,(math.pi/2,0,0))
for x in [-.25,.33]:
    for y in [-.14,.14]:
        cylinder('Isolation foot',.015,.013,(x,y,.007),M['rubber'],base,32,bevel=.002)
        screw('Base fixing',(x,y,.027),M['steel'],base)

# Extruded support column. Recessed channels, end caps, brackets and bolts are geometry.
for x in [-.266,.034]:
    box('2020 support extrusion',(.020,.020,.40),(x,.146,.235),M['metal'],base,.0008)
    for dx in [-.0102,.0102]: box('Extrusion T slot',(.0008,.005,.378),(x+dx,.146,.237),M['black'],base,.0001)
    for dy in [-.0102,.0102]: box('Extrusion T slot',(.005,.0008,.378),(x,.146+dy,.237),M['black'],base,.0001)
    box('Column foot flange',(.047,.038,.006),(x,.146,.032),M['metal'],base,.002)
    for dx in [-.018,.018]:screw('Column foot bolt',(x+dx,.146,.036),M['steel'],base)
    box('Extrusion end cap',(.021,.021,.003),(x,.146,.437),M['black'],base,.001)
rod('Common crossbar',(-.28,.146,.421),(.048,.146,.421),.010,M['metal'],base,32)

cage=empty('Cage',assembly,(-.116,-.015,.028),description='Tecniplast 1264C envelope: 268 × 215 × 141 mm. Taper, radius and wall thickness are visual design estimates.')
rings=[(.229,.174,.014,.000),(.234,.179,.016,.004),(.254,.201,.022,.132),(.268,.215,.025,.137),(.268,.215,.025,.141),(.249,.196,.021,.141),(.249,.196,.021,.134),(.222,.1672,.012,.004)]
verts=[]
for spec in rings: verts+=rounded_ring(*spec,segments=12)
N=48;faces=[]
for j in range(len(rings)-1):
    for i in range(N):faces.append((j*N+i,j*N+(i+1)%N,(j+1)*N+(i+1)%N,(j+1)*N+i))
faces+=[tuple(reversed(range(N))),tuple(range((len(rings)-1)*N,len(rings)*N))]
mesh=bpy.data.meshes.new('Hollow molded polycarbonate cage');mesh.from_pydata(verts,[],faces);mesh.update()
obj=bpy.data.objects.new('Closed solid cage shell',mesh);bpy.context.collection.objects.link(obj);finish(obj,obj.name,M['plastic'],cage,bevel=.0007)
obj['wall_thickness_design_mm']=2.5
# Small molded ribs and a rim ID tab: no opaque or glass cover over the thermal path.
for y in [-.080,.080]:box('Molded base rib',(.18,.002,.0015),(0,y,.001),M['plastic'],cage,.0006)
box('Identification tab',(.036,.0018,.016),(.068,-.101,.12),M['white'],cage,.001)
label('Cage identification','1264C',(.068,-.102,.12),.006,M['blue'],cage,(math.pi/2,0,0))

lid=empty('Grid lid',assembly,tuple(cage.location),description='Flat 1264C025 lid without hopper. Grid pitch and wire diameter are proposed visual approximations; bars obstruct the thermal view.')
edge=rounded_ring(.266,.213,.022,.145,10)
for i,p in enumerate(edge):rod('Lid perimeter',p,edge[(i+1)%len(edge)],.00125,M['steel'],lid,12)
for i in range(-12,13):
    x=i*.0092
    # At these x values the rounded frame has a straight side at y=±106.5 mm.
    rod('Parallel lid wire',(x,-.1065,.145),(x,.1065,.145),.00065,M['steel'],lid,12)
for y in [-.070,.070]:rod('Grid cross brace',(-.133,y,.146),(.133,y,.146),.0010,M['steel'],lid,12)
for x in [-.10,.10]:
    curve('Removable lid clip',[(x,-.105,.146),(x,-.111,.143),(x,-.112,.136),(x,-.105,.134)],.0010,M['steel'],lid)

target=empty('Bench target',assembly,tuple(cage.location),description='Sealed warm-water surrogate for empty-cage coverage checks. Demonstration object, not an animal.')
box('Sealed target capsule',(.090,.042,.021),(0,0,.015),M['target'],target,.010)
cylinder('Target fill cap',.007,.007,(.032,0,.029),M['black'],target,32,bevel=.001)
for x in [-.042,.042]:
    for y in [-.018,.018]:box('Registration mark',(.004,.004,.00015),(x,y,.026),M['mark'],target,.0001)
target['surface_temperature']='No temperature data; illustrative sealed target'

mounts=empty('Camera mounts',assembly,description='Two articulated clamp arms on a common support. Selected assembly positions are design assumptions.')
plate=box('Perforated common mounting plate',(.155,.010,.080),(-.116,.130,.410),M['black'],mounts,.002)
drill(plate,[(x,.130,z) for x in [-.180,-.163,-.146,-.129,-.112,-.095,-.078,-.061] for z in [.384,.401,.418,.435]],.002,.020,(0,1,0))
for side in [-1,1]:
    x=-.116+side*.032
    # Distinct clamp jaw, lead screw and thumb knob.
    box('Super clamp body',(.027,.022,.035),(x,.149,.411),M['black'],mounts,.003)
    box('Clamp fixed jaw',(.027,.027,.009),(x,.14,.438),M['black'],mounts,.002)
    box('Clamp moving jaw',(.024,.023,.008),(x,.14,.390),M['black'],mounts,.002)
    rod('Clamp lead screw',(x,.14,.369),(x,.14,.399),.002,M['steel'],mounts)
    cylinder('Clamp tightening knob',.012,.006,(x,.14,.369),M['black'],mounts,32)
    a=(x,.123,.420);b=(x+side*.025,.066,.463);c=(x+side*.003,-.005,.396)
    for k,p in enumerate([a,b,c]):
        sphere('Arm ball joint',.008,p,M['black'],mounts)
        if k<2:
            cylinder('Arm lock wheel',.012,.008,(p[0],p[1]-.009,p[2]),M['black'],mounts,32,(0,1,0))
            screw('Arm knob centre',(p[0],p[1]-.014,p[2]),M['steel'],mounts,(0,-1,0))
    rod('Adjustable arm lower',a,b,.0045,M['metal'],mounts)
    rod('Adjustable arm upper',b,c,.0045,M['metal'],mounts)
    cylinder('Camera mounting stud',.003,.014,(c[0],c[1],.389),M['steel'],mounts,24)

def camera(name,x,thermal):
    group=empty(name,assembly,(x,-.005,.330),description='Thermal surface camera' if thermal else 'Wide NoIR activity camera')
    col=M['orange'] if thermal else M['teal']
    w,d=(.038,.040) if thermal else (.035,.034)
    carrier=box('Machined camera carrier',(w,d,.010),(0,0,0),M['black'],group,.002)
    box('Insulating backing',(w-.004,d-.004,.001),(0,0,.0056),M['white'],group,.001)
    pcb=(.0258,.0289,.0016) if thermal else (.025,.023862,.00112)
    board=box('Sensor PCB',pcb,(0,0,-.0062),M['pcb'],group,.0003)
    hx=.01035 if thermal else .0105
    hole_rows=[-.01195,.01195] if thermal else [-.009931,.002569]
    drill(board,[(dx,dy,-.0062) for dx in [-hx,hx] for dy in hole_rows],.0011,.006)
    drill(carrier,[(dx,dy,0) for dx in [-hx,hx] for dy in hole_rows],.0011,.016)
    if thermal:
        box('Lepton socket',(.0118,.0127,.001),(0,0,-.00764),M['black'],group,.0003)
        box('Lepton camera body',(.0115,.0127,.0069),(0,0,-.01069),M['metal'],group,.0006)
        cylinder('LWIR objective',.0041,.0004,(0,0,-.0142),M['lens'],group,48,bevel=.00015)
        box('USB-C socket',(.009,.006,.003),(0,.016,-.005),M['steel'],group,.0007)
        box('USB-C plug',(.010,.012,.005),(0,.024,-.004),M['rubber'],group,.001)
        group['field_of_view_h_deg']=57;group['field_of_view_v_deg']=44
        group['field_of_view_v_basis']='Rounded approximation from horizontal field and 4:3 array; no calibrated optical model.'
        group['pixel_resolution']='160 × 120'
    else:
        box('Wide autofocus housing',(.0108,.0108,.0108),(0,.002469,-.0122),M['black'],group,.0008)
        cylinder('Wide objective glass',.003475,.0004,(0,.002469,-.0177),M['lens'],group,48,bevel=.0001)
        torus('Lens barrel detail',.00375,.0003,(0,.002469,-.0175),M['metal'],group)
        box('CSI connector',(.016,.004,.003),(0,.013,-.0065),M['white'],group,.0003)
        group['field_of_view_h_deg']=102;group['field_of_view_v_deg']=67
    for dx in [-hx,hx]:
        for dy in hole_rows:
            pcb_top=-.0062+pcb[2]/2
            washer_height=-.005-pcb_top
            cylinder('Nylon insulating washer',.0017,washer_height,(dx,dy,pcb_top+washer_height/2),M['white'],group,16,bevel=.00008)
            cylinder('M2 camera fixing shaft',.001,.013,(dx,dy,0),M['steel'],group,16,bevel=.00005)
            screw('Camera fastener',(dx,dy,.007),M['steel'],group,radius=.0018)
    box('Channel strip',(w-.005,.003,.001),(0,-d/2+.003,.0065),col,group,.0003)
    label('Camera channel','THERMAL' if thermal else 'ACTIVITY',(0,0,.0066),.0038,M['mark'],group)
    return group
thermal=camera('Thermal camera',-.151,True)
visible=camera('Activity camera',-.081,False)
# Lower the complete mounting system by 46 mm, retaining seated clamp joints.
mounts.location.z=-.046
for obj in base.children:
    if obj.name.startswith('Common crossbar'):obj.location.z-=.046
# Columns remain taller, allowing later height adjustment; crossbar collars stay on them.

ambient=empty('Ambient sensor',assembly,(-.265,-.008,.143),description='SHT45 external temperature and humidity board; protected, ventilated and outside the cage.')
box('Ambient board',(.020,.017,.0016),(0,0,0),M['pcb'],ambient,.0006)
box('SHT45 sensor',(.003,.003,.0012),(0,-.002,.0015),M['steel'],ambient,.0002)
for x in [-.006,.006]:box('QT socket',(.005,.005,.003),(x,.009,.0018),M['white'],ambient,.0004)
for y in [-.005,0,.005]:box('Protective louvre',(.023,.002,.003),(0,y,.007),M['white'],ambient,.0005)
rod('Sensor stand',(-.009,.004,-.115),(-.009,.004,-.001),.003,M['metal'],ambient)
box('Ambient stand foot',(.018,.020,.004),(-.009,.004,-.115),M['metal'],ambient,.001)
for x in [-.010,.010]:
    box('Louvre support',(.002,.015,.006),(x,0,.003),M['white'],ambient,.0005)
for dx in [-.006,.006]:screw('Ambient foot fixing',(-.009+dx,.004,-.1125),M['steel'],ambient,radius=.0015)

optional=empty('Optional piezo',assembly,(-.116,-.015,.027),description='Optional piezo element on an external support plate. Not a verified respiration measurement.')
box('Independent optional support plate',(.250,.186,.002),(0,0,0),M['black'],optional,.005)
for x in [-.10,.10]:
    box('Piezo film with electrode',(.022,.013,.0005),(x,-.087,.0015),M['gold'],optional,.0002)
    curve('Piezo shielded lead',[(x,-.087,.0018),(x,-.109,.004),(.14,-.124,.005),(.15,-.10,.01)],.0008,M['rubber'],optional)
adc=box('ADS1115 external ADC',(.028,.018,.0016),(.156,-.099,.008),M['pcb'],optional,.0005)
drill(adc,[(.156+x,-.099+y,.008) for x in [-.011,.011] for y in [-.006,.006]],.001,.004)
for x in [-.011,.011]:
    for y in [-.006,.006]:
        cylinder('ADC mounting standoff',.0018,.0082,(.156+x,-.099+y,.0031),M['white'],optional,16)
        screw('ADC fixing screw',(.156+x,-.099+y,.009),M['steel'],optional,radius=.0014)
box('ADC IC',(.005,.005,.001),(.156,-.099,.0092),M['black'],optional,.0002)
for x in [.147,.165]:box('ADC terminal',(.004,.008,.003),(x,-.099,.010),M['white'],optional,.0005)

wiring=empty('Signal routing',assembly,description='External routing for USB, CSI and ambient sensing. No cable enters the cage.')
curve('Thermal USB lead',[(-.151,.019,.326),(-.18,.060,.374),(-.22,.143,.368),(-.268,.146,.294),(-.278,.144,.15),(-.244,.14,.05),(.07,.125,.04),(.22,.12,.04),(.34,.08,.047),(.34,-.0205,.0565),(.2785,-.0205,.0565)],.002,M['rubber'],wiring)
fpc=ribbon('500 mm CSI FPC',[(-.081,.010,.3235),(-.036,.026,.337),(.034,.050,.324),(.040,.074,.250),(.046,.082,.140),(.089,.065,.095),(.131,.059,.066),(.131,.052,.069),(.131,.043,.069),(.130,.039,.0665),(.128,.037,.0598)],.009,.00018,M['black'],wiring)
fpc_length=fpc['routed_length_m']
assert fpc_length<=.5, f'FPC exceeds the specified 500 mm: {fpc_length}'
for z,y in [(.25,.074),(.14,.082)]:
    box('External ribbon support',(.011,.070,.003),(.040,.11,z),M['black'],base,.001)
curve('Ambient sensor cable',[(-.265,.001,.142),(-.278,.02,.135),(-.279,.10,.05),(-.23,.144,.043),(.08,.12,.047),(.25,.12,.047),(.2755,.073,.0555)],.0015,M['rubber'],wiring)
curve('Optional ADC lead',[(.04,-.114,.038),(.07,-.125,.04),(.34,-.11,.04),(.346,.08,.047),(.2755,.075,.056)],.001,M['rubber'],wiring)
for z in [.14,.26,.36]:
    torus('Column cable retention',.012,.001,(-.266,.146,z),M['black'],wiring)

try:
    from electronics import build_electronics
    electronics=build_electronics(assembly,ups_drop=-.0255)
    electronics.location=(.216,.015,.026)
except ImportError:
    electronics=empty('Acquisition',assembly,(.216,.015,.03),description='Pi 5 acquisition electronics; detailed asset follows in the next revision.')
    box('Acquisition envelope',(.23,.16,.070),(0,0,.035),M['blue'],electronics,.007)

for component in assembly.children:
    if component.type=='EMPTY':component['component_id']=component.name
from refinements import apply_refinements
refinement_audit=apply_refinements(assembly,M)
join_by_material(assembly)

# Manufacturing/model audit is separate from claims about physical function.
import bmesh
stats={'revision':args.round,'dimension_basis':'Sourced overall envelopes; designed assembly geometry','components':[], 'triangles':0,'meshes':0}
for obj in assembly.children_recursive:
    if obj.type=='MESH':
        obj.data.calc_loop_triangles();stats['triangles']+=len(obj.data.loop_triangles);stats['meshes']+=1
    if obj.type=='EMPTY':stats['components'].append(obj.name)
shell=next(o for o in cage.children if o.type=='MESH' and 'Polycarbonate' in ''.join(m.name for m in o.data.materials))
bm=bmesh.new();bm.from_mesh(shell.data);stats['cage_nonmanifold_edges']=sum(not e.is_manifold for e in bm.edges);bm.free()
stats['cage_envelope_mm']=[268,215,141]
stats['thermal_lens_to_floor_mm']=round(((.330-.0144)-(.028+.004))*1000,1)
stats['CSI_routed_length_mm']=round(fpc_length*1000,1)
stats['camera3_hole_centers_mm']={'horizontal':21,'vertical':12.5,'rows_relative_to_board_center':[-9.931,2.569]}
stats['blender_version']=bpy.app.version_string
stats['refinements']=refinement_audit
stats['lid_wire_endpoints_mm']={'parallel_y':[-106.5,106.5],'cross_brace_x':[-133,133],'basis':'Endpoints meet the illustrative perimeter wire centerline; grid is not manufacturer CAD.'}
(OUT/'geometry-audit.json').write_text(json.dumps(stats,indent=2),encoding='utf-8')

# Export only the instrument. Studio/cameras stay in the editable master, not the web mesh.
bpy.ops.object.select_all(action='DESELECT');assembly.select_set(True)
for obj in assembly.children_recursive:obj.select_set(True)
bpy.context.view_layer.objects.active=assembly
bpy.ops.export_scene.gltf(filepath=str(OUT/'instrument.glb'),export_format='GLB',use_selection=True,export_yup=True,export_extras=True,export_cameras=False,export_lights=False,export_materials='EXPORT',export_apply=True,export_texcoords=False)

ground=material('Studio floor',(.71,.76,.81),.02,.55)
box('Studio plinth',(200,200,.02),(0,0,-.0095),ground,None,0)
scene.world.use_nodes=True
scene.world.node_tree.nodes['Background'].inputs[0].default_value=(.66,.73,.83,1)
scene.world.node_tree.nodes['Background'].inputs[1].default_value=.20
def area(name,location,energy,size,target,color=(1,1,1),size_y=None):
    data=bpy.data.lights.new(name,'AREA');data.energy=energy;data.shape='RECTANGLE';data.size=size;data.size_y=size_y or size;data.color=color
    obj=bpy.data.objects.new(name,data);bpy.context.collection.objects.link(obj);obj.location=location;obj.rotation_euler=(Vector(target)-obj.location).to_track_quat('-Z','Y').to_euler()
area('Large left softbox',(-.5,-.7,1.1),7,.8,(0,0,.2),(1,.94,.85),.6)
area('Right contour softbox',(.6,.3,.9),9,.7,(0,0,.2),(.82,.91,1),.8)
area('Upper strip',(-.1,.45,1.0),5,.7,(-.1,0,.15),(1,1,1),.15)
area('Front low fill',(.15,-.8,.38),2,.55,(0,0,.2),(1,1,1),.35)
data=bpy.data.cameras.new('Product camera');cam=bpy.data.objects.new('Product camera',data);bpy.context.collection.objects.link(cam)
cam.location=(1.02,-1.3,.86);targetpoint=Vector((.16,0,.205));cam.rotation_euler=(targetpoint-cam.location).to_track_quat('-Z','Y').to_euler();data.type='ORTHO';data.ortho_scale=1.08;data.lens=55;scene.camera=cam
scene.render.engine='CYCLES';scene.cycles.samples=args.samples;scene.cycles.use_denoising=True
scene.cycles.max_bounces=10;scene.cycles.transmission_bounces=8;scene.cycles.transparent_max_bounces=8
scene.render.resolution_x=1800;scene.render.resolution_y=1350;scene.render.resolution_percentage=100
scene.view_settings.view_transform='AgX'
scene.render.image_settings.file_format='PNG';scene.render.filepath=str(OUT/'hero.png')
# The editable master opens framed on the instrument, with studio helpers hidden
# only in the viewport. Render visibility and the already-exported GLB are intact.
for obj in list(scene.objects):
    if obj.name=='Studio plinth' or obj.type in {'LIGHT','CAMERA'}:obj.hide_set(True)
bpy.ops.object.select_all(action='DESELECT');assembly.select_set(True)
bpy.context.view_layer.objects.active=assembly
for screen in bpy.data.screens:
    for area_ui in screen.areas:
        if area_ui.type=='VIEW_3D':
            view=area_ui.spaces.active;view.clip_start=.001;view.clip_end=100
            view.region_3d.view_location=targetpoint
            view.region_3d.view_rotation=cam.rotation_euler.to_quaternion()
            view.region_3d.view_distance=1.25
            view.shading.type='MATERIAL'
bpy.ops.wm.save_as_mainfile(filepath=str(OUT/'cage-monitor.blend'))
if args.render:bpy.ops.render.render(write_still=True)
print('INSTRUMENT_BUILD_COMPLETE',json.dumps(stats),flush=True)
