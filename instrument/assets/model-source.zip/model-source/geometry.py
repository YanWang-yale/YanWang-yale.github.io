"""Metre-based procedural parts for the proposed cage monitor."""
import bpy, math
from mathutils import Vector

def material(name, color, metallic=0, roughness=.35, transmission=0, ior=1.5):
    mat=bpy.data.materials.get(name) or bpy.data.materials.new(name)
    mat.use_nodes=True
    node=mat.node_tree.nodes.get('Principled BSDF')
    node.inputs['Base Color'].default_value=(*color,1)
    node.inputs['Metallic'].default_value=metallic
    node.inputs['Roughness'].default_value=roughness
    node.inputs['Transmission Weight'].default_value=transmission
    node.inputs['IOR'].default_value=ior
    mat.diffuse_color=(*color,1)
    if transmission:
        group=bpy.data.node_groups.get('glTF Material Output')
        if group is None:
            group=bpy.data.node_groups.new('glTF Material Output','ShaderNodeTree')
            group.interface.new_socket(name='Thickness',in_out='INPUT',socket_type='NodeSocketFloat')
        g=mat.node_tree.nodes.new('ShaderNodeGroup');g.node_tree=group
        g.inputs['Thickness'].default_value=.0025
        volume=mat.node_tree.nodes.new('ShaderNodeVolumeAbsorption')
        volume.inputs['Color'].default_value=(.91,.98,1,1)
        volume.inputs['Density'].default_value=.15
        mat.node_tree.links.new(volume.outputs['Volume'],mat.node_tree.nodes.get('Material Output').inputs['Volume'])
    return mat

def empty(name, parent=None, location=(0,0,0), description=None):
    obj=bpy.data.objects.new(name,None);bpy.context.collection.objects.link(obj)
    obj.parent=parent;obj.location=location
    if description: obj['description']=description
    return obj

def drill(obj, centers, radius, depth, axis=(0,0,1)):
    """Subtract real through-holes, with positions local to the part's parent."""
    for p in centers:
        cutter=cylinder('Temporary hole tool',radius,depth,p,None,obj.parent,24,axis,bevel=0)
        bpy.context.view_layer.update()
        modifier=obj.modifiers.new('Through hole','BOOLEAN');modifier.operation='DIFFERENCE'
        modifier.solver='EXACT';modifier.object=cutter
        bpy.context.view_layer.objects.active=obj
        bpy.ops.object.modifier_apply(modifier=modifier.name)
        bpy.data.objects.remove(cutter,do_unlink=True)
    # Boolean n-gons must remain planar; smooth shading bends the metal around holes.
    for poly in obj.data.polygons:
        poly.use_smooth=False
    # Weighted normals from the pre-cut box no longer describe Boolean corners.
    # Clear them explicitly; Blender 5.2 otherwise retains triangulated highlights.
    if obj.data.has_custom_normals:
        obj.data.normals_split_custom_set([(0,0,0)]*len(obj.data.loops))
    return obj

def finish(obj,name,mat,parent=None,bevel=0):
    obj.name=name
    if mat: obj.data.materials.append(mat)
    obj.parent=parent
    if bevel:
        modifier=obj.modifiers.new('Manufactured edge radius','BEVEL');modifier.width=bevel;modifier.segments=3
        modifier.affect='EDGES'
        bpy.context.view_layer.objects.active=obj
        bpy.ops.object.modifier_apply(modifier=modifier.name)
    for poly in obj.data.polygons: poly.use_smooth=True
    if bevel:
        normal=obj.modifiers.new('Face weighted normals','WEIGHTED_NORMAL');normal.keep_sharp=True;normal.weight=40
        bpy.context.view_layer.objects.active=obj
        bpy.ops.object.modifier_apply(modifier=normal.name)
    return obj

def box(name,size,loc,mat,parent=None,bevel=.001):
    bpy.ops.mesh.primitive_cube_add(size=1,location=loc)
    obj=bpy.context.object;obj.dimensions=size
    bpy.ops.object.transform_apply(location=False,rotation=False,scale=True)
    return finish(obj,name,mat,parent,bevel)

def cylinder(name,radius,depth,loc,mat,parent=None,vertices=32,axis=(0,0,1),bevel=.0005):
    bpy.ops.mesh.primitive_cylinder_add(vertices=vertices,radius=radius,depth=depth,location=loc)
    obj=bpy.context.object;obj.rotation_euler=Vector(axis).to_track_quat('Z','Y').to_euler()
    return finish(obj,name,mat,parent,bevel)

def rod(name,a,b,radius,mat,parent=None,vertices=20):
    a,b=Vector(a),Vector(b);d=b-a
    return cylinder(name,radius,d.length,(a+b)/2,mat,parent,vertices,d,bevel=radius*.17)

def sphere(name,radius,loc,mat,parent=None,scale=(1,1,1)):
    bpy.ops.mesh.primitive_uv_sphere_add(segments=24,ring_count=12,radius=radius,location=loc)
    obj=bpy.context.object;obj.scale=scale
    bpy.ops.object.transform_apply(location=False,rotation=False,scale=True)
    return finish(obj,name,mat,parent)

def torus(name,major,minor,loc,mat,parent=None,axis=(0,0,1)):
    bpy.ops.mesh.primitive_torus_add(major_segments=40,minor_segments=8,major_radius=major,minor_radius=minor,location=loc)
    obj=bpy.context.object;obj.rotation_euler=Vector(axis).to_track_quat('Z','Y').to_euler()
    return finish(obj,name,mat,parent)

def screw(name,loc,mat,parent=None,axis=(0,0,1),radius=.0028):
    # A real recessed hex socket with a floor and six planar walls, no dark decal.
    dark=bpy.data.materials.get('Socket recess') or material('Socket recess',(.014,.018,.023),.25,.45)
    n=24; edge=min(.00035,radius*.17); verts=[]; faces=[]; sides=[]
    for r,z in [(radius-edge,-.0011),(radius,-.0011+edge),(radius,.0011-edge),(radius-edge,.0011)]:
        verts.extend((r*math.cos(i*math.tau/n),r*math.sin(i*math.tau/n),z) for i in range(n))
    hexagon=[Vector((radius*.46*math.cos(i*math.tau/6),radius*.46*math.sin(i*math.tau/6),0)) for i in range(6)]
    for z in [.0011,.00020]:
        for i in range(n):
            p=hexagon[i//4].lerp(hexagon[(i//4+1)%6],(i%4)/4)
            verts.append((p.x,p.y,z))
    faces.append(tuple(reversed(range(n))));sides.append(0)
    for row in range(5):
        for i in range(n):
            j=(i+1)%n
            faces.append((row*n+i,row*n+j,(row+1)*n+j,(row+1)*n+i));sides.append(0)
    faces.append(tuple(range(5*n,6*n)));sides.append(1)
    mesh=bpy.data.meshes.new(name+' recessed socket');mesh.from_pydata(verts,[],faces);mesh.update()
    mesh.materials.append(mat);mesh.materials.append(dark)
    obj=bpy.data.objects.new(name,mesh);bpy.context.collection.objects.link(obj);obj.parent=parent;obj.location=loc
    obj.rotation_euler=Vector(axis).to_track_quat('Z','Y').to_euler()
    for p,mi in zip(mesh.polygons,sides):p.material_index=mi
    return obj

def curve(name,points,radius,mat,parent=None):
    data=bpy.data.curves.new(name,'CURVE');data.dimensions='3D';data.resolution_u=12
    data.bevel_depth=radius;data.bevel_resolution=3
    spline=data.splines.new('BEZIER');spline.bezier_points.add(len(points)-1)
    for point,co in zip(spline.bezier_points,points):
        point.co=co;point.handle_left_type='AUTO';point.handle_right_type='AUTO'
    obj=bpy.data.objects.new(name,data);bpy.context.collection.objects.link(obj)
    obj.data.materials.append(mat);obj.parent=parent
    bpy.context.view_layer.objects.active=obj;obj.select_set(True)
    bpy.ops.object.convert(target='MESH');obj=bpy.context.object;obj.select_set(False)
    return obj

def label(name,text,loc,size,mat,parent=None,rotation=(0,0,0)):
    data=bpy.data.curves.new(name,'FONT');data.body=text;data.size=size;data.extrude=0;data.align_x='CENTER';data.align_y='CENTER';data.resolution_u=3
    obj=bpy.data.objects.new(name,data);bpy.context.collection.objects.link(obj);obj.location=loc;obj.rotation_euler=rotation;obj.parent=parent;data.materials.append(mat)
    bpy.ops.object.select_all(action='DESELECT');obj.select_set(True);bpy.context.view_layer.objects.active=obj;bpy.ops.object.convert(target='MESH');obj.select_set(False)
    return obj

def ribbon(name,points,width,thickness,mat,parent=None):
    """A finite-thickness FPC, with Catmull-Rom bending and measured length."""
    control=[Vector(points[0])]+[Vector(p) for p in points]+[Vector(points[-1])]
    samples=[]
    for i in range(1,len(control)-2):
        p0,p1,p2,p3=control[i-1:i+3]
        for j in range(10):
            t=j/10
            samples.append(.5*((2*p1)+(-p0+p2)*t+(2*p0-5*p1+4*p2-p3)*t*t+(-p0+3*p1-3*p2+p3)*t*t*t))
    samples.append(Vector(points[-1]))
    verts=[];faces=[]
    for i,p in enumerate(samples):
        tangent=(samples[min(i+1,len(samples)-1)]-samples[max(i-1,0)]).normalized()
        u=Vector((0,1,0)).cross(tangent).normalized()
        if u.length<.5:u=Vector((1,0,0))
        v=tangent.cross(u).normalized()
        verts.extend(p+su*u*width/2+sv*v*thickness/2 for su,sv in [(-1,-1),(1,-1),(1,1),(-1,1)])
    for i in range(len(samples)-1):
        for k in range(4):faces.append((4*i+k,4*i+(k+1)%4,4*(i+1)+(k+1)%4,4*(i+1)+k))
    faces.extend([(3,2,1,0),tuple(range(4*(len(samples)-1),4*len(samples)))])
    mesh=bpy.data.meshes.new(name);mesh.from_pydata(verts,[],faces);mesh.update()
    obj=bpy.data.objects.new(name,mesh);bpy.context.collection.objects.link(obj);finish(obj,name,mat,parent)
    obj['routed_length_m']=sum((b-a).length for a,b in zip(samples,samples[1:]))
    return obj

def rounded_ring(width,depth,radius,z,segments=8):
    points=[]
    for cx,cy,start in [(width/2-radius,depth/2-radius,0),(-width/2+radius,depth/2-radius,90),(-width/2+radius,-depth/2+radius,180),(width/2-radius,-depth/2+radius,270)]:
        for i in range(segments):
            angle=math.radians(start+90*i/segments)
            points.append((cx+radius*math.cos(angle),cy+radius*math.sin(angle),z))
    return points

def join_by_material(parent):
    """Keep component groups; merge material batches only within each group."""
    # A recessed screw has two materials. Split those faces first so its steel
    # can share the existing steel batch instead of adding an extra draw call.
    for obj in list(parent.children):
        if obj.type!='MESH' or len(obj.data.materials)<2:continue
        old=obj.data
        for index in sorted({p.material_index for p in old.polygons}):
            polygons=[p for p in old.polygons if p.material_index==index]
            used=sorted({i for p in polygons for i in p.vertices})
            remap={source:i for i,source in enumerate(used)}
            mesh=bpy.data.meshes.new(obj.name+' material '+str(index))
            mesh.from_pydata([old.vertices[i].co[:] for i in used],[],[tuple(remap[i] for i in p.vertices) for p in polygons]);mesh.update()
            mesh.materials.append(old.materials[index])
            for new,previous in zip(mesh.polygons,polygons):new.use_smooth=previous.use_smooth
            part=obj.copy();part.data=mesh;part.name=obj.name+' material '+str(index)
            bpy.context.collection.objects.link(part)
        bpy.data.objects.remove(obj,do_unlink=True)
        if old.users==0:bpy.data.meshes.remove(old)
    groups={}
    for obj in list(parent.children):
        if obj.type=='EMPTY': join_by_material(obj)
        elif obj.type=='MESH':
            key=tuple(slot.material.name if slot.material else '' for slot in obj.material_slots)
            groups.setdefault(key,[]).append(obj)
    for names,parts in groups.items():
        if len(parts)<2: continue
        bpy.ops.object.select_all(action='DESELECT')
        for obj in parts:obj.select_set(True)
        bpy.context.view_layer.objects.active=parts[0];bpy.ops.object.join()
        obj=bpy.context.object;obj.name=parent.name+' | '+(', '.join(names));obj.select_set(False)
